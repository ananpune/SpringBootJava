package ca.sheridancollege;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalExamPuneetAnandApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalExamPuneetAnandApplication.class, args);
	}

}
