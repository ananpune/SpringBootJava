package ca.sheridancollege;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A2P2Application {

	public static void main(String[] args) {
		SpringApplication.run(A2P2Application.class, args);
	}

}
