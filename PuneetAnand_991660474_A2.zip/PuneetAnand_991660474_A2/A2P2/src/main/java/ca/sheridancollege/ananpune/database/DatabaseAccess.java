package ca.sheridancollege.ananpune.database;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.ananpune.beans.Car;


@Repository
public class DatabaseAccess {
	@Autowired
	protected NamedParameterJdbcTemplate jdbc;
	
	public void insertCar(String make, String model, int cyear, double eindex) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query="INSERT INTO cars(make,model,cyear,eindex) VALUES(:make,:model,:cyear,:eindex)";
		namedParameters.addValue("make", make);
		namedParameters.addValue("model", model);
		namedParameters.addValue("cyear", cyear);
		namedParameters.addValue("eindex", eindex);
		int rowsAffected = jdbc.update(query, namedParameters);
		if (rowsAffected > 0)
		System.out.println("Inserted car into database.");
		}
	
	public void deleteCar(Long id) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "DELETE FROM cars WHERE id = :id";
		namedParameters.addValue("id", id);
		int rowsAffected = jdbc.update(query, namedParameters);
		if (rowsAffected > 0)
		System.out.println("Deleted car " + id + " from database");
		}
	
	
	public List<Car> getCars() {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM cars";
		return jdbc.query(query, namedParameters, new
		BeanPropertyRowMapper<Car>(Car.class));
	}
	public List<Car> getCarById(Long id) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM cars WHERE id = :id";
		namedParameters.addValue("id", id);
		return jdbc.query(query, namedParameters, new
		BeanPropertyRowMapper<Car>(Car.class));
		}

}
