package ca.sheridancollege.ananpune.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.ananpune.beans.Car;
import ca.sheridancollege.ananpune.beans.Credentials;
import ca.sheridancollege.ananpune.database.DatabaseAccess;



@Controller
public class CarController {
	
	@Autowired
	private DatabaseAccess da;
	
	@Autowired
	private Credentials message;
	
	@GetMapping("/")
	public String index(Model model) {
		System.out.println(message);

		model.addAttribute("car", new Car());
		

		return "index";
		
	}
	@PostMapping("/insertCar")
	public String insertCar(Model model, @ModelAttribute Car car) {
	da.insertCar(car.getMake(),car.getModel(),car.getCyear(),car.getEindex());
	model.addAttribute("car", new Car());
	model.addAttribute("carList", da.getCars());
	return "index";
	}
	
	@GetMapping("/deleteCar/{id}")
	public String deleteCar(Model model, @PathVariable Long id) {
		da.deleteCar(id);
		model.addAttribute("car", new Car());
		model.addAttribute("carList", da.getCars());
		return "index";
	}
	@GetMapping("/editCar/{id}")
	public String editCar(Model model, @PathVariable Long id) {
		Car car = da.getCarById(id).get(0);
		model.addAttribute(car);
		da.deleteCar(id);
		model.addAttribute("carList", da.getCars());
		System.out.println("Enter new EV specifications");
		return "index";
	}

}
