package ca.sheridancollege.ananpune.controllers;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.ananpune.beans.Credentials;
import ca.sheridancollege.ananpune.beans.Volume;
import ca.sheridancollege.ananpune.database.DatabaseAccess;

@Controller
public class VolumeController {
	
	@Autowired
	private Credentials message;
	
	@Autowired
	private DatabaseAccess da;
	
	
	

	
	@GetMapping("/")
	public String index(Model model) {
		System.out.println(message);
		model.addAttribute("volume", new Volume());
		return "index";
		
	}
	
	@PostMapping("/insertVolume")
	public String insertVolume(Model model, @ModelAttribute Volume volume) {
		da.insertVolume(volume.getLen(), volume.getWid(), volume.getHei(), volume.getVol());
		model.addAttribute("volume", new Volume());
		model.addAttribute("volumeList", da.getVolumes());
		return "index";
	}
	
	@GetMapping("/deleteVolume/{id}")
	public String deleteVolume(Model model, @PathVariable Long id) {
		da.deleteVolume(id);
		model.addAttribute("volume", new Volume());
		model.addAttribute("volumeList", da.getVolumes());
		return "index";
		
	}
	
	@GetMapping("/editVolume/{id}")
	public String editVolume(Model model, @PathVariable Long id) {
		Volume volume = da.getVolumeById(id).get(0);
		model.addAttribute(volume);
		da.deleteVolume(id);
		model.addAttribute("volumeList", da.getVolumes());
		System.out.println("Enter new height length and width");
		return "index";
	}
}
