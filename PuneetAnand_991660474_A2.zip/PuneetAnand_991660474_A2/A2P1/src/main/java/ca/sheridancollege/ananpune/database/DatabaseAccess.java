package ca.sheridancollege.ananpune.database;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;


import ca.sheridancollege.ananpune.beans.Volume;

@Repository
public class DatabaseAccess {
	
	@Autowired
	protected NamedParameterJdbcTemplate jdbc;
	
	// public void insertVolume() {
	//	MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		//String query="INSERT INTO volume(volume) VALUES (3)";
		//int rowsAffected = jdbc.update(query, namedParameters);
		
		//if (rowsAffected > 0)
		//System.out.println("Inserted volume into database.");
		
	//}

	public void insertVolume(int len, int hei, int wid,  int Volume) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		namedParameters.addValue("volume", Volume);
		namedParameters.addValue("len", len);
		namedParameters.addValue("wid", wid);
		namedParameters.addValue("hei", hei);
		String query="INSERT INTO volume(hei,wid,len,volume) VALUES (:hei,:wid,:len,:volume)";
		int rowsAffected = jdbc.update(query, namedParameters);
		if (rowsAffected > 0) 
			System.out.println("Inserted volume into database.");
	}
	public void deleteVolume(Long id) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "DELETE FROM volume WHERE id = :id";
		namedParameters.addValue("id", id);
		int rowsAffected = jdbc.update(query, namedParameters);
		if (rowsAffected > 0)
		System.out.println("Deleted volume " + id + " from database");
		}
	
	public List<Volume> getVolumes() {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM volume";
		return jdbc.query(query, namedParameters, new
		BeanPropertyRowMapper<Volume>(Volume.class));
	}
	public List<Volume> getVolumeById(Long id) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM volume WHERE id = :id";
		namedParameters.addValue("id", id);
		
		return jdbc.query(query, namedParameters, new
		BeanPropertyRowMapper<Volume>(Volume.class));
		}
	

}
