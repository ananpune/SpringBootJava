CREATE TABLE volume(
	id LONG PRIMARY KEY AUTO_INCREMENT,
	len INT,
	wid INT,
	hei INT,
	volume INT
	
	
);