package ca.sheridancollege.ananpune;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import ca.sheridancollege.ananpune.beans.*;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A1P3_Tests {

	@Test
	void buildHybridCar() {
		
		HybridCar test = new HybridCar("Honda", "Civic", 2017,"EV", 0.9);
		assertEquals(test.getMake(), "Honda");
		assertEquals(test.getModel(), "Civic");
		assertEquals(test.getYear(), 2017);
		assertEquals(test.getType(), "EV");
		assertEquals(test.getIndex(), 0.9);
		
		
		
		
		
	}

}
