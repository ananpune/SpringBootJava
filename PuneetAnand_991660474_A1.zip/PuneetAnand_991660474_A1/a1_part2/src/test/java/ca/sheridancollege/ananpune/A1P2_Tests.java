package ca.sheridancollege.ananpune;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;
import ca.sheridancollege.ananpune.beans.*;

@SpringBootTest
class A1P2_Tests {

	@Test
	void buildSolarHome() {
		
		SolarHome test = new SolarHome("Victorian", 3000, 1.2, "North", "heated");
		assertEquals(test.getStyle(), "Victorian");
		assertEquals(test.getSize(), 3000);
		assertEquals(test.getIndex(), 1.2);
		assertEquals(test.getDirection(), "North");
		assertEquals(test.getType(), "heated");
		
		
	}

}
