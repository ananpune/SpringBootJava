package ca.sheridancollege.ananpune.beans;

public class SolarHome {
	private String style;
	private int size;
	private double index;
	private String direction;
	private String type;
	
	public SolarHome(String style, int size, double index, String direction, String type) {
		this.style = style;
		this.size = size;
		this.index = index;
		this.direction = direction;
		this.type = type;
	}
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public double getIndex() {
		return index;
	}
	public void setIndex(double index) {
		this.index = index;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "style=" + this.style + " size=" + this.size + " index=" + this.index + " direciton=" + this.direction + " type=" + type;
	}
	
	
	

}
