package ca.sheridancollege.ananpune.controllers;


import ca.sheridancollege.ananpune.beans.*;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class SolarHomeController {


	
	
	@GetMapping("/")
	public String index(Model model) {
		
		return "index";
	}
	
	@PostMapping("/formPost")
	public String formPost(@RequestParam String homeStyle, @RequestParam int size, 
			@RequestParam double index, @RequestParam String direction, @RequestParam String type)
			 {
		
		SolarHome sh = new SolarHome(homeStyle, size, index, direction, type);
		System.out.println(sh.toString());
		
		
		return "working";
	}
	
}
