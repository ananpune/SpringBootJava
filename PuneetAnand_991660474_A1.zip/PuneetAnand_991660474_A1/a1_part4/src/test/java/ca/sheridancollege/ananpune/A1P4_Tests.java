package ca.sheridancollege.ananpune;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import ca.sheridancollege.ananpune.beans.ReusableRocket;

@SpringBootTest
class A1P4_Tests {

	@Test
	void buildRocket() {
		ReusableRocket test = new ReusableRocket("Apollo", "1200m", "1000lbs",3);
		assertEquals(test.getName(), "Apollo");
		assertEquals(test.getHeight(), "1200m");
		assertEquals(test.getCapacity(), "1000lbs");
		assertEquals(test.getReuses(), 3);
	}

}
