package ca.sheridancollege.ananpune.beans;

public class ReusableRocket {
	private String name; 
	private String height;
	private String capacity;
	private int reuses;
	
	public ReusableRocket(String name, String height, String capacity, int reuses) {
		super();
		this.name = name;
		this.height = height;
		this.capacity = capacity;
		this.reuses = reuses;
	}

	@Override
	public String toString() {
		return "ReusableRocket [name=" + name + ", height=" + height + ", capacity=" + capacity + ", reuses=" + reuses
				+ "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public int getReuses() {
		return reuses;
	}

	public void setReuses(int reuses) {
		this.reuses = reuses;
	}
	
	
	
	

}
