package ca.sheridancollege.ananpune.controllers;


import ca.sheridancollege.ananpune.beans.*;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class ResuableRocketController {


	
	
	@GetMapping("/")
	public String index(Model model) {
		
		return "index";
	}
	
	@PostMapping("/formPost")
	public String formPost(@RequestParam String name,@RequestParam String height, @RequestParam String capacity, 
			@RequestParam int reuse)
			 {
		ReusableRocket rr = new ReusableRocket(name, height, capacity, reuse);
		System.out.println(rr.toString());
		
		
	
		
		return "working";
	}
	
}
