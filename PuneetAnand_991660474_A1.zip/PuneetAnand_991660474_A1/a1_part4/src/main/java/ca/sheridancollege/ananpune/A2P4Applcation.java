package ca.sheridancollege.ananpune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A2P4Applcation {

	public static void main(String[] args) {
		SpringApplication.run(A2P4Applcation.class, args);
	}

}
