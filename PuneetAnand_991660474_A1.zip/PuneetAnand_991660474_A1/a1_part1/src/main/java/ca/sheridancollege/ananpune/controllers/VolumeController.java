package ca.sheridancollege.ananpune.controllers;


import ca.sheridancollege.ananpune.beans.*;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class VolumeController {

	@Autowired
	private Message message;
	
	
	@GetMapping("/")
	public String index(Model model) {
		System.out.println(message);
		return "index";
	}
	
	@PostMapping("/formPost")
	public String formPost(@RequestParam int length, @RequestParam int width, 
			@RequestParam int height)
			 {
		
		Volume vol = new Volume(length, width, height);
		
		
		return "results";
	}
	
}
