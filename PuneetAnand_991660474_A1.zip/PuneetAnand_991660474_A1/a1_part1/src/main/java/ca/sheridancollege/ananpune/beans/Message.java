package ca.sheridancollege.ananpune.beans;

import org.springframework.stereotype.Component;

@Component
public class Message {

	private String sayThis = "Puneet Anand 991660474";

	@Override
	public String toString() {
		return "Message [Name and Student Number: " + sayThis + "]";
	}
	
}