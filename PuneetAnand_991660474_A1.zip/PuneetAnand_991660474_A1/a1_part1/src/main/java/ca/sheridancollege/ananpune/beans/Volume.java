package ca.sheridancollege.ananpune.beans;

public class Volume {
	private int len;
	private int wid;
	private int hei;
	private int vol;
	
	public Volume (int len, int wid, int hei) {
		this.len=len;
		this.wid=wid;
		this.hei=hei;
		
		this.vol=len*wid*hei;;
		
		System.out.println("Volume is: " + vol);
		
	}

	public int getLen() {
		return len;
	}

	public void setLen(int len) {
		this.len = len;
	}

	public int getWid() {
		return wid;
	}

	public void setWid(int wid) {
		this.wid = wid;
	}

	public int getHei() {
		return hei;
	}

	public void setHei(int hei) {
		this.hei = hei;
	}

}
