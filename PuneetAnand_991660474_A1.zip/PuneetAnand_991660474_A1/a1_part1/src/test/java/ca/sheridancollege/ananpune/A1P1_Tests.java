package ca.sheridancollege.ananpune;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;
import ca.sheridancollege.ananpune.beans.*;

@SpringBootTest
class A1P1_Tests {

	@Test
	void buildVolume() {
		
		Volume test =  new Volume(3,2,1);
		assertEquals(test.getHei(), Long.valueOf(1));
		assertEquals(test.getLen(), Long.valueOf(2));
		assertEquals(test.getWid(), Long.valueOf(3));
		
		
		
	}

}
