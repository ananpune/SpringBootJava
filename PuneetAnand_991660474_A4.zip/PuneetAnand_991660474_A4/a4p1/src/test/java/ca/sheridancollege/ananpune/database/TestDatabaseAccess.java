package ca.sheridancollege.ananpune.database;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureTestDatabase

public class TestDatabaseAccess {
	
	@Autowired
	private DatabaseAccess da;
	@Test
	public void whenInsertVolume_getVolume() {
		da.insertVolume(3, 2, 1, 6);
		Assert.assertTrue(da.getVolumes().size()>0);
	}
	@Test
	public void whenDeleteVolume_getVolume() {
		da.insertVolume(3, 2, 1, 6);
		da.deleteVolume(Long.valueOf(1));
		Assert.assertTrue(da.getVolumes().size()==0);
	}
	

}
