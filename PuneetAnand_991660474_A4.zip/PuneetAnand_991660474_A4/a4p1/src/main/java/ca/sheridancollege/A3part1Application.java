package ca.sheridancollege;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A3part1Application {

	public static void main(String[] args) {
		SpringApplication.run(A3part1Application.class, args);
	}

}
