package ca.sheridancollege.ananpune.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class Volume {
	
	private Long id;
	private int hei;
	private int wid;
	private int len;
	private int volume;
	
	public Volume(Long id,int hei,int wid,int len) {
		this.id=id;
		this.hei=hei;
		this.len=len;
		this.wid = wid;
		this.volume = this.hei*this.len*this.wid;
	}
	
	public int getVol() {
		return this.hei*this.len*this.wid;
	}
	
	
	

}
