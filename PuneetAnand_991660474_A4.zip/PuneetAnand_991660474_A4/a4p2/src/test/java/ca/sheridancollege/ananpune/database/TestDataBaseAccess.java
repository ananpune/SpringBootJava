package ca.sheridancollege.ananpune.database;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureTestDatabase
public class TestDataBaseAccess {
	@Autowired
	private DatabaseAccess da;
	
	
	@Test
	public void whenInsertCar_getCars() {
		da.insertCar("Honda", "Civic", 2001, 1.2);
		Assert.assertTrue(da.getCars().size()>0);;
	}
	@Test
	public void whenDeleteCar_getCars() {
		da.insertCar("Honda", "Civic", 2001, 1.2);
		da.deleteCar(Long.valueOf(1));
		Assert.assertTrue(da.getCars().size()==0);;
	}



}
