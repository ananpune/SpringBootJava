package ca.sheridancollege.ananpune.controllers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import ca.sheridancollege.ananpune.beans.Car;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureTestDatabase
@AutoConfigureMockMvc
public class TestCarController {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Test
	public void testLoadingIndex() throws Exception {
		this.mockMvc.perform(get("/"))
		.andExpect(status().isOk())
		.andExpect(view().name("index"));
	}
	@Test
	public void testLoadingInsertCar() throws Exception {
	this.mockMvc.perform(post("/insertCar").flashAttr("car", new Car()))
	.andExpect(status().isOk())
	.andExpect(view().name("index"));
	}
	@Test
	public void testLoadingDeleteCar() throws Exception {
	this.mockMvc.perform(post("/deleteCar").flashAttr("car", new Car()))
	.andExpect(status().isOk())
	.andExpect(view().name("index"));
	}
	@Test
	public void testLoadingeditCar() throws Exception {
	this.mockMvc.perform(post("/editCar").flashAttr("car", new Car()))
	.andExpect(status().isOk())
	.andExpect(view().name("index"));
	}

}
