CREATE TABLE cars (
	id LONG PRIMARY KEY AUTO_INCREMENT,
	make VARCHAR(255) NOT NULL,
	model VARCHAR(255),
	cyear INT,
	eindex double );
