CREATE TABLE manufacturer( 
	id LONG PRIMARY KEY AUTO_INCREMENT, 
	manufacturer VARCHAR(255), 
	country VARCHAR(255),
	email VARCHAR(255), 
	shippingDate DATE, 
	shippingTime VARCHAR(255) 
); 

INSERT INTO manufacturer(manufacturer, country, email, shippingDate, shippingTime) VALUES 
('Siemens', 'Germany', 'info.canada@siemens.com', '2021-01-01', '12:00:00'), 
('ABB', 'Sweden', 'info@gmail.com', '2021-02-02', '08:15:00'), 
('Bombardier', 'Canada', 'support@yahoo.ca', '2021-03-03', '14:30:00'), 
('GE', 'USA', 'info.ge@outlook.com', '2021-04-04', '10:15:00'); 

