package ca.sheridancollege.ananpune.beans;

import org.springframework.stereotype.Component;

@Component
public class Credentials {

	private String sayThis = "Puneet Anand ananpune 991660474";

	@Override
	public String toString() {
		return "Message [Name, Student ID, Student Number: " + sayThis + "]";
	}
	
}