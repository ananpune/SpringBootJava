package ca.sheridancollege.ananpune.controllers;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.ananpune.beans.Credentials;
import ca.sheridancollege.ananpune.beans.Manufacturer;

import ca.sheridancollege.ananpune.database.DatabaseAccess;

@Controller
public class ManufacturerController {
	
	@Autowired
	private DatabaseAccess da;
	
	

	@GetMapping("/")
	public String index(Model model) {
		
		model.addAttribute("manufacturer", new Manufacturer());
		model.addAttribute("manufacturerList", da.getManufacturers());
		da.insertManufacturer();
		return "index";
		
	}
	
	@PostMapping("/insertManufacturer")
	public String insertManufacturer(Model model, @ModelAttribute Manufacturer manufacturer) {
		da.insertManufacturer(manufacturer.getManufacturer(), manufacturer.getCountry(), manufacturer.getEmail(),manufacturer.getShippingDate(), manufacturer.getShippingTime()+":00");
		model.addAttribute("manufacturer", new Manufacturer());
		model.addAttribute("manufacturerList", da.getManufacturers());
		return "index";
	}
	
	@GetMapping("/deleteManufacturer/{id}")
	public String deleteManufacturer(Model model, @PathVariable Long id) {
		da.deleteManufacturer(id);
		model.addAttribute("manufacturer", new Manufacturer());
		model.addAttribute("manufacturerList", da.getManufacturers());
		return "index";
		
	}
	
	@GetMapping("/editManufacturer/{id}")
	public String editManufacturer(Model model, @PathVariable Long id) {
		Manufacturer manufacturer = da.getManufacturerById(id).get(0);
		model.addAttribute(manufacturer);
		da.deleteManufacturer(id);
		model.addAttribute("manufacturerList", da.getManufacturers());
		System.out.println("Enter new information");
		return "index";
	}
}
