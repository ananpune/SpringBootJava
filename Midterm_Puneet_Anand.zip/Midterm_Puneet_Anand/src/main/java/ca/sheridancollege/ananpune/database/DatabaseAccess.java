package ca.sheridancollege.ananpune.database;

import java.time.LocalDate;

import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

import ca.sheridancollege.ananpune.beans.Manufacturer;



@Repository
public class DatabaseAccess {
	
	@Autowired
	protected NamedParameterJdbcTemplate jdbc;
	
	public void insertManufacturer() {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query="INSERT INTO manufacturer(manufacturer,country,email,shippingDate, shippingTime) VALUES ('Bob','Canada','info@Bob.com','2021-01-01','12:00:00' )";
		int rowsAffected = jdbc.update(query, namedParameters);
		if (rowsAffected > 0) 
			System.out.println("Inserted manufacturer into database.");
	}

	public void insertManufacturer(String manufacturer, String country, String email, Date shippingDate, String shippingTime) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		namedParameters.addValue("manufacturer", manufacturer);
		namedParameters.addValue("country", country);
		namedParameters.addValue("email", email);
		namedParameters.addValue("shippingDate", shippingDate);
		namedParameters.addValue("shippingTime", shippingTime);
		String query="INSERT INTO manufacturer(manufacturer,country,email,shippingDate, shippingTime) VALUES (:manufacturer,:country,:email,:shippingDate,:shippingTime)";
		int rowsAffected = jdbc.update(query, namedParameters);
		if (rowsAffected > 0) 
			System.out.println("Inserted manufacturer into database.");
	}
	public void deleteManufacturer(Long id) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "DELETE FROM manufacturer WHERE id = :id";
		namedParameters.addValue("id", id);
		int rowsAffected = jdbc.update(query, namedParameters);
		if (rowsAffected > 0)
		System.out.println("Deleted manufacturer " + id + " from database");
		}
	
	public List<Manufacturer> getManufacturers() {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM manufacturer";
		return jdbc.query(query, namedParameters, new
		BeanPropertyRowMapper<Manufacturer>(Manufacturer.class));
	}
	public List<Manufacturer> getManufacturerById(Long id) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		String query = "SELECT * FROM manufacturer WHERE id = :id";
		namedParameters.addValue("id", id);
		
		return jdbc.query(query, namedParameters, new
		BeanPropertyRowMapper<Manufacturer>(Manufacturer.class));
		}
	

}
