package ca.sheridancollege.ananpune.beans;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class Manufacturer {
	
	private Long id;
	private String manufacturer;
	private String country;
	private String email;
	private Date shippingDate;
	private String shippingTime;
	
	

	

}
